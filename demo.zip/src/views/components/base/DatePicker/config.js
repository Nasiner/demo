const config = {"name":"DatePicker","attr":{"type":"month","placeholder":"选择月"}}
 module.exports = config