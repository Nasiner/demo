const config = {"name":"TimePicker","attr":{"start":"09:30","end":"18:30"}}
 module.exports = config