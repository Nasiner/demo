const config = {
  name: 'DateTimePicker',
  attr: {
    type: 'datetime',
    placeholder: '选择日期时间'
  }
}
module.exports = config
