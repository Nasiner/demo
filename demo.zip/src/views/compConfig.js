
const showName = [
  {
    value: 'TimePicker',
    label: 'TimePicker'
  },
  {
    value: 'DatePicker',
    label: 'DatePicker'
  },
  {
    value: 'DateTimePicker',
    label: 'DateTimePicker'
  }
]
export default showName
